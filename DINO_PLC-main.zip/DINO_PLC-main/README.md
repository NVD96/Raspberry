# DINO PLC v1.0.6
- ERROR LED message can be found at address D900 
# DINO PLC v1.0.5
- DINO Webserver              --  added
  - Blynk 1.0 ,Blynk 2.2  -- Supported
  - MQTT Simple mode      -- Supported
  - Line notify           -- Supported
- Built-in Modbus TCP Server  --  added
  - FC01,FC02
  - FC03,FC04
  - FC05,FC06
- NTP Server RTC              --  added
  - Sync duration can be adjusted
# DINO PLC v1.0.4
- PLC Modbus RTU maste      -- added
- PLC Modbus RUT slave      -- added 
# DINO PLC v1.0.3
- Library error             -- fixed
- Library name changed
- RTC function example      -- added
# DINO PLC v1.0.2
- Re-install to lib manager 
# DINO PLC v1.0.1
- Change InitPLC to initPLC
- Change clearM  to resetM
# DINO PLC v1.0.0
- First released
