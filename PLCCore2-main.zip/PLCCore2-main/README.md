# PLCCore2
   This is PLCCore base for ESP32 Control ,MiniPLC-32u ,DinoPLC ,MiniPLC-S3 ,This library can be use to allow 
 as mentions hardware to be work as Real PLC.If you want to order PLC hardware please contact us as facebook.com/TFMaker
# Edition released
 # - v 1.0 
   - First released