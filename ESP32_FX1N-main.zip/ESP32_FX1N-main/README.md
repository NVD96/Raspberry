This is PLC Arduino library for DINO PLC

Library require (Library ที่จำเป็น)
- ArduinoJson
- StreamUtils
- ESP32Time

** User need to install above library before complie example prpject **
** ผู้ใช้งานต้องติดตั้ง Library ข้างบนก่อน ถึงจะสามารถใช้งานได้ครับ **

# ESP32 FX1N v1.0.3
